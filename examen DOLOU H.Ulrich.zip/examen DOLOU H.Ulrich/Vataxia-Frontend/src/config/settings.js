const settings = {

    API_ROOT: process.env.API_ROOT,

    // User roles
    ADMINISTRATOR: 'administrator',
    MODERATOR: 'moderator',

};

export default settings;
