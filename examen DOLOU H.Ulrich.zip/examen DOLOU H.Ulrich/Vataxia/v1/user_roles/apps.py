from django.apps import AppConfig


class UserRolesConfig(AppConfig):
    name = 'v1.user_roles'
