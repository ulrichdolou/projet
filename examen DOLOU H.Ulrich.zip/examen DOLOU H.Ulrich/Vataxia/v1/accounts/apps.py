from django.apps import AppConfig


class AccountsConfig(AppConfig):
    name = 'v1.accounts'
