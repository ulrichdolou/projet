from django.apps import AppConfig


class CreditsConfig(AppConfig):
    name = 'v1.credits'
