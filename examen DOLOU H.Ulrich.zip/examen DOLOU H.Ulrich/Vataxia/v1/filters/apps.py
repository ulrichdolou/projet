from django.apps import AppConfig


class FiltersConfig(AppConfig):
    name = 'v1.filters'
