from django.apps import AppConfig


class PrivateMessagesConfig(AppConfig):
    name = 'v1.private_messages'
