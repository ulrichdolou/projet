from django.contrib import admin
from .models.private_message import PrivateMessage


admin.site.register(PrivateMessage)
