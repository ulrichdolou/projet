from django.contrib import admin
from .models.post_vote import PostVote


admin.site.register(PostVote)
