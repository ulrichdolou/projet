from django.apps import AppConfig


class RepliesConfig(AppConfig):
    name = 'v1.replies'
