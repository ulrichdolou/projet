from django.contrib import admin
from .models.post_reply import PostReply


admin.site.register(PostReply)
