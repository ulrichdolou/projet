from django.apps import AppConfig


class PostsConfig(AppConfig):
    name = 'v1.posts'
